package com.automation.flightbooking.utils;

public class ProjectConstants {
	
	public static final String EXPECTED_TITLE = "BlazeDemo";
	public static final String URL = "https://blazedemo.com/";
	

}
