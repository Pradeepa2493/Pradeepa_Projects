package com.automation.flightbooking.testexecution;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.automation.flightbooking.utils.Xpath;
import com.automation.flightbooking.utils.ProjectConstants;
import com.automation.flightbooking.utils.Xls_Reader;

public class TicketBooking {
	public static WebDriver driver;

	public static void main(String[] args) throws InterruptedException {
		WebElement element = null;
		System.setProperty("webdriver.chrome.driver", "C:\\Pradeepa\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://blazedemo.com/");
		Thread.sleep(2000);
		driver.manage().window().maximize();
		Thread.sleep(2000);
		String expectedTitle = ProjectConstants.EXPECTED_TITLE;
		String actualTitle = driver.getTitle();
		System.out.println(actualTitle);
		if (expectedTitle.contentEquals(actualTitle)) {
			// Choose departure city
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.DEPARTURE_CITY));
			element.click();
			// Choose destination city
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.DESTINATION_CITY));
			element.click();
			// Find Flights
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.FIND_FLIGHTS));
			element.click();
			Thread.sleep(3000);

			// Select flight
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.SELECT_FLIGHTS));
			element.click();
		}
		Thread.sleep(2000);
		// Validate page
	//	if(driver.getPageSource().contains("Your flight from TLV to SFO has been reservedriver.")) {
			System.out.println("Entered");
			Thread.sleep(2000);
			// Fill out form
			Xls_Reader reader = new Xls_Reader("./src/test/java/com/automation/flightbooking/utils/Testdata.xlsx");
			String sheetName = "formfill";
			String name = reader.getCellData(sheetName, 0, 2);
			String address = reader.getCellData(sheetName, 1, 2);
			String city = reader.getCellData(sheetName, 2, 2);
			String state = reader.getCellData(sheetName, 3, 2);
			String zipcode = reader.getCellData(sheetName, 4, 2);
			String ccnum = reader.getCellData(sheetName, 5, 2);
			String month = reader.getCellData(sheetName, 6, 2);
			String year = reader.getCellData(sheetName, 7, 2);
			String nameoncard = reader.getCellData(sheetName, 8, 2);

			element = driver.findElement(By.xpath(Xpath.NAME));
			element.sendKeys(name);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.ADDRESS));
			element.sendKeys(address);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.CITY));
			element.sendKeys(city);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.STATE));
			element.sendKeys(state);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.ZIP));
			element.sendKeys(zipcode);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.CC_TYPE));
			element.click();
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.CC_NUM));
			element.sendKeys(ccnum);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.MONTH));
			element.clear();
			element.sendKeys(month);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.YEAR));
			element.clear();
			element.sendKeys(year);
			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.NAME_ON_CARD));
			element.sendKeys(nameoncard);

			Thread.sleep(2000);
			element = driver.findElement(By.xpath(Xpath.PURCHASE_FLIGHT));
			element.click();
		/*} else {
			System.out.println("Failed");
		}*/

		Thread.sleep(2000);
		if (driver.getPageSource().contains("Thank you for your purchase today!")) {
			String str = driver.findElement(By.xpath(Xpath.GET_TABLE)).getText();
			System.out.println(str);
		}
	}
}
