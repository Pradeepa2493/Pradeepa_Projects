package com.automation.flightbooking.utils;

public class Xpath {
	
	public static final String DEPARTURE_CITY = "//*[@name='fromPort']/option[3]";
	public static final String DESTINATION_CITY = "//*[@name='toPort']/option[5]";
	public static final String FIND_FLIGHTS = "//*[@type='submit']";
	public static final String SELECT_FLIGHTS = "//*[@name='VA43']/following-sibling::td[1]/input";
	public static final String GET_TABLE = "//*[@class='table']/tbody";
	public static final String PURCHASE_FLIGHT = "//*[@class='btn btn-primary']";
	public static final String NAME = "//*[@id='inputName']";
	public static final String ADDRESS = "//*[@id='address']";
	public static final String CITY = "//*[@id='city']";
	public static final String STATE = "//*[@id='state']";
	public static final String ZIP = "//*[@id='zipCode']";
	public static final String CC_TYPE = "//*[@class='form-inline']/option[1]";
	public static final String CC_NUM = "//*[@id='creditCardNumber']";
	public static final String MONTH = "//*[@id='creditCardMonth']";
	public static final String YEAR = "//*[@id='creditCardYear']";
	public static final String NAME_ON_CARD = "//*[@id='nameOnCard']";
}
