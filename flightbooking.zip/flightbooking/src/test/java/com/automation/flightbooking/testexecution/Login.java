package com.automation.flightbooking.testexecution;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login {

	public static void main(String[] args) throws InterruptedException
	{
		WebElement element = null;
		System.setProperty("webdriver.chrome.driver", "C:\\Pradeepa\\chromedriver\\chromedriver.exe");
		WebDriver d= new ChromeDriver();
		d.get("https://blazedemo.com/");
		Thread.sleep(2000);
		d.manage().window().maximize();
		Thread.sleep(2000);
		String expectedTitle = "BlazeDemo";
		String actualTitle = d.getTitle();
		System.out.println(actualTitle);
		if(expectedTitle.contentEquals(actualTitle)) {
			Thread.sleep(2000);
			element = d.findElement(By.xpath("/html/body/div[1]/div/div/a[3]"));
			element.click();
			Thread.sleep(2000);
			element = d.findElement(By.xpath("//*[contains(text(),'Login')]"));
			element.click();
			Thread.sleep(2000);
			element = d.findElement(By.xpath("//*[@id='email']"));
			element.click();
			Thread.sleep(2000);
			element = d.findElement(By.xpath("//*[@id='password']"));
			element.click();
			Thread.sleep(2000);
			element = d.findElement(By.xpath("//*[@type='submit']"));
			element.click();
}
	}
}
